#!/bin/bash

# ==============================================================================
# REDMAGIC NUBIA NOVA TABLET (NP03J) - UNIFIED BOOTLOADER UNLOCK TOOL
# ==============================================================================

# Determine script directory for portability
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

LOADER="${SCRIPT_DIR}/bin/prog_ufs_firehose_sm8650_v2_ddr.elf"
PATCHED_ABL="${SCRIPT_DIR}/bin/abl_eng_v2.img"
FRP_UNLOCK="${SCRIPT_DIR}/bin/frp_unlock.img"
MISC_WIPE="${SCRIPT_DIR}/bin/misc_wipedata.img"

# Backup directory (backups are saved here in Step 1, and restored from here in Step 2)
BACKUP_DIR="${SCRIPT_DIR}/backups"

ORIG_ABL_A="${BACKUP_DIR}/abl_a_backup.elf"
ORIG_ABL_B="${BACKUP_DIR}/abl_b_backup.elf"
ORIG_FRP="${BACKUP_DIR}/frp_backup.img"

# Colors for UI
GREEN="\033[0;32m"
YELLOW="\033[1;33m"
RED="\033[0;31m"
BLUE="\033[0;34m"
NC="\033[0m" # No Color

# Helper function to check if device is in EDL mode
check_edl() {
    lsusb | grep -q "05c6:9008"
    return $?
}

# Helper function to check if device is in Fastboot mode
check_fastboot() {
    fastboot devices | grep -q "fastboot"
    return $?
}

# Helper function to run EDL command with pkexec
run_edl() {
    local args=("$@")
    local cmd=("pkexec" "/usr/bin/edl" "--loader=$LOADER")
    
    # Do not append --memory=UFS for reset command
    if [[ " ${args[*]} " != *" reset "* ]]; then
        cmd+=("--memory=UFS")
    fi
    
    cmd+=("${args[@]}")
    echo -e "${BLUE}Running: ${cmd[*]}${NC}"
    "${cmd[@]}"
    return $?
}

# Banner
echo -e "${GREEN}"
echo "=================================================================="
echo "          REDMAGIC NOVA (NP03J) BOOTLOADER UNLOCK TOOL            "
echo "=================================================================="
echo -e "${NC}"

echo "Select an option:"
echo -e "1) ${YELLOW}Step 1: Backup and Flash Engineering Bootloader (EDL Mode)${NC}"
echo -e "2) ${YELLOW}Unlock Command (Fastboot Mode)${NC}"
echo -e "3) ${YELLOW}Step 2: Restore Stock Bootloader and Wipe Data (EDL Mode)${NC}"
echo -e "4) Exit"
echo -n "Option [1-4]: "
read -r opt

case $opt in
    1)
        echo -e "\n${YELLOW}[1/3] Preparing Step 1...${NC}"
        mkdir -p "$BACKUP_DIR"
        
        # Ensure root logs directory exists for EDL client logger bug
        pkexec mkdir -p /root/logs
        
        echo -e "${YELLOW}Please connect the tablet in EDL mode now.${NC}"
        echo "Instructions: Power off, hold Vol Up + Vol Down + Power, and plug in USB."
        echo "Waiting for EDL device (05c6:9008)..."
        while ! check_edl; do
            sleep 1
        done
        echo -e "${GREEN}EDL device detected!${NC}"
        
        # 1. Backup
        echo -e "\n${YELLOW}[2/3] Backing up current partitions...${NC}"
        if ! run_edl "--lun=4" "r" "abl_a" "$ORIG_ABL_A"; then
            echo -e "${RED}Failed to backup abl_a!${NC}"; exit 1
        fi
        if ! run_edl "--lun=4" "r" "abl_b" "$ORIG_ABL_B"; then
            echo -e "${RED}Failed to backup abl_b!${NC}"; exit 1
        fi
        if ! run_edl "--lun=0" "r" "frp" "$ORIG_FRP"; then
            echo -e "${RED}Failed to backup frp!${NC}"; exit 1
        fi
        
        # 2. Flash Eng ABL & FRP Unlock
        echo -e "\n${YELLOW}[3/3] Flashing Engineering ABL and FRP Unlock...${NC}"
        if ! run_edl "--lun=4" "w" "abl_a" "$PATCHED_ABL"; then
            echo -e "${RED}Failed to flash patched ABL to abl_a!${NC}"; exit 1
        fi
        if ! run_edl "--lun=4" "w" "abl_b" "$PATCHED_ABL"; then
            echo -e "${RED}Failed to flash patched ABL to abl_b!${NC}"; exit 1
        fi
        if ! run_edl "--lun=0" "w" "frp" "$FRP_UNLOCK"; then
            echo -e "${RED}Failed to flash frp_unlock!${NC}"; exit 1
        fi
        
        # 3. Reset
        echo -e "\n${GREEN}Step 1 Completed! Resetting device...${NC}"
        run_edl "reset"
        echo -e "${GREEN}Tablet should now reboot. Proceed to Option 2 once it is in Fastboot.${NC}"
        ;;
        
    2)
        echo -e "\n${YELLOW}Waiting for Fastboot device...${NC}"
        echo "Ensure the tablet is on the Fastboot/bootloader screen."
        while ! check_fastboot; do
            sleep 1
        done
        echo -e "${GREEN}Fastboot device detected!${NC}"
        
        echo -e "${YELLOW}Sending unlock command...${NC}"
        fastboot flashing unlock
        echo -e "${GREEN}Unlock command sent! Please confirm on the tablet screen using Volume keys and Power key.${NC}"
        ;;
        
    3)
        echo -e "\n${YELLOW}[1/2] Preparing Step 2 (Restore Stock)...${NC}"
        
        # Check stock backups exist
        if [ ! -f "$ORIG_ABL_A" ] || [ ! -f "$ORIG_ABL_B" ] || [ ! -f "$ORIG_FRP" ]; then
            echo -e "${RED}Error: Stock backups not found in ${BACKUP_DIR}!${NC}"
            echo "You must run Step 1 first to create backups before restoring."
            exit 1
        fi
        
        echo -e "${YELLOW}Please connect the tablet in EDL mode.${NC}"
        echo "Instructions: Power off/reboot, hold Vol Up + Vol Down + Power, and plug in USB."
        echo "Waiting for EDL device (05c6:9008)..."
        while ! check_edl; do
            sleep 1
        done
        echo -e "${GREEN}EDL device detected!${NC}"
        
        # 1. Restore ABL and FRP
        echo -e "\n${YELLOW}[2/2] Restoring original stock bootloader & FRP...${NC}"
        if ! run_edl "--lun=4" "w" "abl_a" "$ORIG_ABL_A"; then
            echo -e "${RED}Failed to restore stock abl_a!${NC}"; exit 1
        fi
        if ! run_edl "--lun=4" "w" "abl_b" "$ORIG_ABL_B"; then
            echo -e "${RED}Failed to restore stock abl_b!${NC}"; exit 1
        fi
        if ! run_edl "--lun=0" "w" "frp" "$ORIG_FRP"; then
            echo -e "${RED}Failed to restore stock frp!${NC}"; exit 1
        fi
        
        # 2. Flash wipe data trigger
        echo -e "\n${YELLOW}Flashing wipe data trigger to misc...${NC}"
        if ! run_edl "--lun=0" "w" "misc" "$MISC_WIPE"; then
            echo -e "${RED}Failed to flash misc wipe!${NC}"; exit 1
        fi
        
        # 3. Reset
        echo -e "\n${GREEN}Step 2 Completed! Resetting device...${NC}"
        run_edl "reset"
        echo -e "${GREEN}Done! The tablet will boot into Android with an unlocked bootloader.${NC}"
        ;;
        
    *)
        echo "Exiting."
        exit 0
        ;;
esac
